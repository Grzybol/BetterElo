package betterbox.mine.game.betterelo;

import org.bukkit.OfflinePlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.List;


public class BetterEloCommand implements CommandExecutor {

    private final DataManager dataManager;
    private final JavaPlugin plugin;
    private final PluginLogger pluginLogger;
    private final GuiManager guiManager; // Dodajemy referencję do GuiManager
    private BetterElo betterElo;
    public String state;


    public BetterEloCommand(JavaPlugin plugin, DataManager dataManager, GuiManager guiManager, PluginLogger pluginLogger, BetterElo betterElo) {
        this.dataManager = dataManager;
        this.plugin = plugin;

        this.guiManager = guiManager; // Inicjalizujemy referencję do GuiManager
        this.pluginLogger = pluginLogger;
        this.betterElo = betterElo; // Inicjalizujemy referencję do BetterElo


    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (args.length == 0) {
            // /be - Information about the player's rank and points
            if (sender instanceof Player) {
                Player player = (Player) sender;
                int rank = dataManager.getPlayerRank(player.getUniqueId().toString());
                double points = dataManager.getPoints(player.getUniqueId().toString());
                sender.sendMessage(ChatColor.GREEN + "[BetterElo] " + ChatColor.WHITE + "Your rank: " + rank);
                sender.sendMessage(ChatColor.GREEN + "[BetterElo] " + ChatColor.WHITE + "Your points: " + points);
            } else {
                sender.sendMessage(ChatColor.RED + "[BetterElo] This command can only be used by online players.");
            }
        } else if (args[0].equalsIgnoreCase("info")) {
            // /be info - Plugin information
            sender.sendMessage(ChatColor.GREEN + "[BetterElo] Plugin for managing player ranking on BetterBox.");
            sender.sendMessage(ChatColor.GREEN + "Author: grzybol");
            sender.sendMessage(ChatColor.GREEN + "Version: 1.0");
        } else if (args.length == 1 && args[0].equalsIgnoreCase("top10")) {
            // /be top10 - Displays the top 10 players and their points
            sender.sendMessage(ChatColor.GREEN + "[BetterElo] Top 10 players in the ranking:");
            for (int i = 1; i <= 10; i++) {
                String playerName = dataManager.getPlayerAtPosition(i);
                double points = dataManager.getPointsAtPosition(i);
                if (playerName != null) {
                    sender.sendMessage(ChatColor.GREEN.toString() + i + ". " + playerName + " - Points: " + points);
                }
            }
        }else if (args.length == 1 && args[0].equalsIgnoreCase("claim")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "[BetterElo] This command can only be used by online players.");
                return true;
            }

            Player player = (Player) sender;
            String playerName = player.getName();

            File rewardsFile = new File(plugin.getDataFolder(), "offlineRewards.yml");
            if (!rewardsFile.exists()) return true;

            FileConfiguration rewardsConfig = YamlConfiguration.loadConfiguration(rewardsFile);
            List<ItemStack> rewardItems = (List<ItemStack>) rewardsConfig.getList(playerName);

            if (rewardItems != null && !rewardItems.isEmpty()) {
                for (ItemStack item : rewardItems) {
                    player.getInventory().addItem(item);
                }
                rewardsConfig.set(playerName, null); // Usuń przyznane nagrody z pliku
                try {
                    rewardsConfig.save(rewardsFile);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }else if (args.length == 1 && args[0].equalsIgnoreCase("timeleft")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "[BetterElo] This command can only be used by online players.");
                return true;
            }

            Player player = (Player) sender;

                long dailyTimeLeft = betterElo.getRemainingTimeForDailyRewards();
                long weeklyTimeLeft = betterElo.getRemainingTimeForWeeklyRewards();
                long monthlyTimeLeft = betterElo.getRemainingTimeForMonthlyRewards();

                player.sendMessage(ChatColor.GREEN + "[BetterElo] Remaining time for daily rewards: " + formatTime(dailyTimeLeft));
                player.sendMessage(ChatColor.GREEN + "[BetterElo] Remaining time for weekly rewards: " + formatTime(weeklyTimeLeft));
                player.sendMessage(ChatColor.GREEN + "[BetterElo] Remaining time for monthly rewards: " + formatTime(monthlyTimeLeft));

        }else if (args.length == 1 && args[0].equalsIgnoreCase("setrewards")) {
            if (!sender.hasPermission("betterelo.setrewards")) {
                sender.sendMessage(ChatColor.RED + "[BetterElo] Nie masz uprawnień do tej komendy.");
                return true;
            }
            // /be setrewards - Otwiera interfejs GUI do ustawiania nagród
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "[BetterElo] This command can only be used by online players.");
                return true;
            }

            Player player = (Player) sender;
            guiManager.openMainGui(player); // Otwieramy główne menu GUI dla gracza
        }else if (args.length == 1) {
            // /be <player_name> - Information about a specific player's rank and points
            String playerName = args[0];

            // Pobierz obiekt OfflinePlayer dla danego gracza
            OfflinePlayer targetPlayer = Bukkit.getOfflinePlayer(playerName);

            // Sprawdź, czy gracz istnieje w bazie danych pluginu
            String playerUUID = targetPlayer.getUniqueId().toString();
            if (!dataManager.playerExists(playerUUID)) {
                sender.sendMessage(ChatColor.RED + "[BetterElo] Player with the name " + playerName + " has never played on this server.");
                return true;
            }

            // Sprawdź, czy gracz o podanej nazwie istnieje w rankingu
            int rank = dataManager.getPlayerRank(playerUUID);
            if (rank == -1) {
                sender.sendMessage(ChatColor.RED + "[BetterElo] Player with the name " + playerName + " was not found in the ranking.");
                return true;
            }

            double points = dataManager.getPoints(playerUUID);
            sender.sendMessage(ChatColor.GREEN + "[BetterElo] Player " + playerName + " is ranked " + rank + ".");
            sender.sendMessage(ChatColor.GREEN + "[BetterElo] Player's points: " + points);
        }
        else if (args.length == 2 && args[0].equalsIgnoreCase("top")) {
            // /be top <n> - Displays the nickname and points of the player in position n in the ranking
            try {
                int position = Integer.parseInt(args[1]);
                String playerName = dataManager.getPlayerAtPosition(position);
                double points = dataManager.getPointsAtPosition(position);
                if (playerName != null) {
                    sender.sendMessage(ChatColor.GREEN + "[BetterElo] Player in position " + position + ": " + playerName);
                    sender.sendMessage(ChatColor.GREEN + "[BetterElo] Player's points: " + points);
                } else {
                    sender.sendMessage(ChatColor.RED + "[BetterElo] No player in position " + position + " in the ranking.");
                }
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "[BetterElo] Please enter a valid ranking position number.");
            }
            // ... [reszta kodu]

        }else if (args.length == 2 && args[0].equalsIgnoreCase("be")) {
            if (!sender.hasPermission("betterelo.manage")) {
                sender.sendMessage(ChatColor.RED + "[BetterElo] Nie masz uprawnień do tej komendy.");
                return true;
            }
            // /be <daily/weekly/monthly> <on/off> - Enables or disables reward functions
            String rewardType = args[1].toLowerCase();
            state = args[2].toLowerCase();

            if (!rewardType.equals("daily") && !rewardType.equals("weekly") && !rewardType.equals("monthly")) {
                sender.sendMessage(ChatColor.RED + "[BetterElo] Invalid reward type. Use daily, weekly or monthly.");
                return true;
            }

            if (!state.equals("on") && !state.equals("off")) {
                sender.sendMessage(ChatColor.RED + "[BetterElo] Invalid state. Use on or off.");
                return true;
            }
            if (state.equals("on")) {
                sender.sendMessage(ChatColor.GREEN + "[BetterElo] " + rewardType + " rewards have been turned " + state + ".");
                return true;
            }
            if (state.equals("off")) {
                sender.sendMessage(ChatColor.GREEN + "[BetterElo] " + rewardType + " rewards have been turned " + state + ".");
                return true;
            }

        } else {

        }



        return true;
    }
    private String formatTime(long millis) {
        long seconds = millis / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        return String.format("%d days, %d hours, %d minutes, %d seconds", days, hours % 24, minutes % 60, seconds % 60);
    }
}
