package betterbox.mine.game.betterelo;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class Placeholders extends PlaceholderExpansion {

    private final DataManager dataManager;

    public Placeholders(DataManager dataManager) {
        this.dataManager = dataManager;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "be";
    }

    @Override
    public @NotNull String getAuthor() {
        return "grzybol";
    }

    @Override
    public @NotNull String getVersion() {
        return "1.0";
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onPlaceholderRequest(Player player, String identifier) {
        // Sprawdź, który placeholder jest używany
        if (player != null) {
            if (identifier.equals("player")) {
                // Placeholder "{betterelo_player}" - zwraca punkty gracza
                double points = dataManager.getPoints(player.getUniqueId().toString());
                return String.valueOf(points);
            } else if (identifier.equals("rank")) {
                // Placeholder "{betterelo_rank}" - zwraca miejsce w rankingu gracza
                int rank = dataManager.getPlayerRank(player.getUniqueId().toString());
                return String.valueOf(rank);
            } else if (identifier.startsWith("points_top")) {
                // Placeholder "{betterelo_points_top<n>}" - zwraca punkty gracza na pozycji n w rankingu
                int position = Integer.parseInt(identifier.replace("points_top", ""));
                double points = dataManager.getPointsAtPosition(position);
                return String.valueOf(points);
            } else if (identifier.startsWith("player_top")) {
                // Placeholder "{betterelo_player_top<n>}" - zwraca nazwę gracza na pozycji n w rankingu
                int position = Integer.parseInt(identifier.replace("player_top", ""));
                String playerName = dataManager.getPlayerAtPosition(position);
                return playerName != null ? playerName : "No Player";
            }
        } else {
            // Gracz jest offline
            OfflinePlayer offlinePlayer = dataManager.getOfflinePlayer(identifier);

            if (offlinePlayer != null) {
                if (identifier.equals("killed")) {
                    // Placeholder "{betterelo_killed}" - zwraca punkty ofiary
                    double victimPoints = dataManager.getPoints(offlinePlayer.getUniqueId().toString());
                    return String.valueOf(victimPoints);
                } else if (identifier.equals("killer")) {
                    // Placeholder "{betterelo_killer}" - zwraca punkty zabójcy
                    double killerPoints = dataManager.getPoints(offlinePlayer.getUniqueId().toString());
                    return String.valueOf(killerPoints);
                }
            }
        }

        return null; // Placeholder nie został rozpoznany
    }
}
