package betterbox.mine.game.betterelo;

import org.bukkit.entity.Player;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.*;
import java.util.*;

import java.io.*;
import java.util.*;

public class DataManager {

    private final JavaPlugin plugin;
    private final File dataFolder;
    private final File databaseFile;
    private final Map<String, Double> playerPoints = new HashMap<>();
    private final PluginLogger pluginLogger; // Dodajemy referencję do PluginLogger

    public DataManager(JavaPlugin plugin, PluginLogger pluginLogger) {
        this.plugin = plugin;
        this.pluginLogger = pluginLogger; // Inicjalizujemy PluginLogger
        this.dataFolder = plugin.getDataFolder();
        this.databaseFile = new File(dataFolder, "database.txt");
    }
    public void setPoints(String playerUUID, double points) {
        playerPoints.put(playerUUID, points);
        pluginLogger.log("DataManager: setPoints: zapisuwanie do bazy..");
        saveDataToFile(); // Zapisz zmienione dane do pliku

    }

    public void initializeDataFolder() {
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
    }

    public void initializeDatabaseFile() {
        if (!databaseFile.exists()) {
            try {
                databaseFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public File getDatabaseFile() {
        return databaseFile;
    }
    public int getPlayerRank(String playerUUID) {
        if (!playerPoints.containsKey(playerUUID)) {
            return -1; // Gracz nie jest w rankingu
        }
        double playerPoints = getPoints(playerUUID);
        Map<String, Double> sortedPlayers = sortPlayersByPoints();

        int rank = 1;
        for (Map.Entry<String, Double> entry : sortedPlayers.entrySet()) {
            if (entry.getKey().equals(playerUUID)) {
                return rank;
            }
            rank++;
        }

        return rank; // Gracz nie jest w rankingu
    }
    public void loadDataFromFile() {
        playerPoints.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(databaseFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    String playerUUID = parts[0];
                    double points = Double.parseDouble(parts[1]);
                    playerPoints.put(playerUUID, points);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Używamy nowego loggera do zapisywania wiadomości debugujących
        pluginLogger.log("DataManager: loadDataFromFile: wczytano z bazy..");
    }

    public void saveDataToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(databaseFile))) {
            for (Map.Entry<String, Double> entry : playerPoints.entrySet()) {
                String playerUUID = entry.getKey();
                double points = entry.getValue();
                writer.write(playerUUID + ":" + points);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Używamy nowego loggera do zapisywania wiadomości debugujących
        pluginLogger.log("Dane zapisane do pliku database.txt.");
    }
    public double getMaxElo() {
        if (playerPoints.isEmpty()) {
            return 1500; // Zwróć 1500, jeśli mapa punktów jest pusta
        }

        // Przejście przez wszystkie wartości w mapie i znalezienie najwyższej wartości ELO
        double maxElo = Collections.max(playerPoints.values());

        return maxElo;
    }

    public double getPoints(String playerUUID) {
        if (!playerPoints.containsKey(playerUUID)) {
            return -1; // Gracz nie jest w rankingu
        }
        return playerPoints.get(playerUUID);
    }

    public double getPointsAtPosition(int position) {
        Map<String, Double> sortedPlayers = sortPlayersByPoints();

        int rank = 1;
        for (Map.Entry<String, Double> entry : sortedPlayers.entrySet()) {
            if (rank == position) {
                return entry.getValue(); // Znaleziono gracza na danej pozycji w rankingu
            }
            rank++;
        }

        return 0; // Brak gracza na danej pozycji w rankingu
    }

    public String getPlayerAtPosition(int position) {
        Map<String, Double> sortedPlayers = sortPlayersByPoints();

        int rank = 1;
        for (Map.Entry<String, Double> entry : sortedPlayers.entrySet()) {
            if (rank == position) {
                // Znaleziono gracza na danej pozycji w rankingu
                return getPlayerName(entry.getKey());
            }
            rank++;
        }

        return null; // Brak gracza na danej pozycji w rankingu
    }
    public String getPlayerName(String playerUUID) {
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(UUID.fromString(playerUUID));
        return offlinePlayer != null ? offlinePlayer.getName() : null;
    }
    public OfflinePlayer getOfflinePlayer(String playerIdentifier) {
        // Sprawdź, czy gracz jest online
        Player onlinePlayer = Bukkit.getPlayer(playerIdentifier);
        if (onlinePlayer != null) {
            return onlinePlayer;
        }

        // Gracz jest offline - próba uzyskania obiektu OfflinePlayer
        UUID playerUUID;
        try {
            playerUUID = UUID.fromString(playerIdentifier);
        } catch (IllegalArgumentException e) {
            return null; // Nieprawidłowy identyfikator gracza
        }

        return Bukkit.getOfflinePlayer(playerUUID);
    }
    public boolean playerExists(String playerUUID) {
        loadDataFromFile(); // Wczytaj dane z pliku przed sprawdzeniem

        return playerPoints.containsKey(playerUUID);
    }
    private Map<String, Double> sortPlayersByPoints() {
        Map<String, Double> sortedPlayers = new LinkedHashMap<>();

        playerPoints.entrySet()
                .stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .forEachOrdered(entry -> sortedPlayers.put(entry.getKey(), entry.getValue()));

        return sortedPlayers;
    }


}
