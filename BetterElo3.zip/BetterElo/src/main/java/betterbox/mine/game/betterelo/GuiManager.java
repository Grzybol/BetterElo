package betterbox.mine.game.betterelo;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class GuiManager implements Listener {

    private final FileRewardManager fileRewardManager;
    private final BetterElo mainClass;
    private final PluginLogger pluginLogger;

    public GuiManager(FileRewardManager fileRewardManager, PluginLogger pluginLogger, BetterElo mainClass) {
        this.fileRewardManager = fileRewardManager;
        this.mainClass = mainClass;
        this.pluginLogger = pluginLogger;
    }

    public void openMainGui(Player player) {
        Inventory inv = Bukkit.createInventory(null, 9, "Set Rewards");
        createItem(inv, Material.APPLE, 1, "daily", "Daily Reward");
        createItem(inv, Material.BREAD, 3, "weekly", "Weekly Reward");
        createItem(inv, Material.DIAMOND, 5, "monthly", "Monthly Reward");
        player.openInventory(inv);
    }

    private void createItem(Inventory inv, Material material, int slot, String name, String description) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(Collections.singletonList(description));
        item.setItemMeta(meta);
        inv.setItem(slot, item);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTitle().equals("Set Rewards")) {
            event.setCancelled(true);
            if (event.getCurrentItem() == null || event.getCurrentItem().getType() == Material.AIR)
                return;
            // Ustawiamy typ nagrody, który został kliknięty
            String rewardType = event.getCurrentItem().getItemMeta().getDisplayName();
            fileRewardManager.setRewardType(rewardType);

            // Wczytaj obecne nagrody dla wybranego typu nagrody
            List<ItemStack> currentRewards = fileRewardManager.loadRewards();

            // Tworzymy nowy interfejs użytkownika z 36 slotami
            Inventory inv = Bukkit.createInventory(null, 36, "Add Items");

            // Dodajemy wczytane nagrody do interfejsu użytkownika
            for(ItemStack reward : currentRewards){
                inv.addItem(reward);
            }

            // Dodajemy przyciski zapisywania, resetowania i rozdawania nagród
            createItem(inv, Material.GREEN_WOOL, 35, "Save", "Zapisz przedmioty");
            createItem(inv, Material.ORANGE_WOOL, 34, "Reset", "Resetuj czas");
            createItem(inv, Material.YELLOW_WOOL, 33, "Reedem", "Rozdaj nagrody");

            // Otwieramy nowy interfejs użytkownika
            event.getWhoClicked().openInventory(inv);
        }  else if (event.getView().getTitle().equals("Add Items")) {
            if (event.getCurrentItem() != null && event.getCurrentItem().getType() != Material.AIR) {
                String clickedItemName = event.getCurrentItem().getItemMeta().getDisplayName();

                if ("Save".equals(clickedItemName)) {
                    event.setCancelled(true);

                    // Pobierz wszystkie przedmioty z inwentarza, które nie są "AIR"
                    List<ItemStack> nonAirItems = Arrays.stream(event.getInventory().getContents())
                            .filter(item -> item != null && item.getType() != Material.AIR)
                            .filter(item -> !item.getType().equals(Material.GREEN_WOOL) ||
                                    !"Save".equals(item.getItemMeta().getDisplayName())) // Dodatkowe sprawdzenie
                            .filter(item -> !item.getType().equals(Material.ORANGE_WOOL) ||
                                    !"Reset".equals(item.getItemMeta().getDisplayName())) // Dodatkowe sprawdzenie dla Reset
                            .filter(item -> !item.getType().equals(Material.YELLOW_WOOL) ||
                                    !"Reedem".equals(item.getItemMeta().getDisplayName())) // Dodatkowe sprawdzenie dla Reset
                            .collect(Collectors.toList());

                    if (nonAirItems.isEmpty()) {
                        Player player = (Player) event.getWhoClicked();
                        player.sendMessage("Brak przedmiotów do zapisania!");
                        return;
                    }

                    Inventory tempInventory = Bukkit.createInventory(null, 9, "Temporary Inventory");
                    for (ItemStack item : nonAirItems) {
                        tempInventory.addItem(item);
                    }

                    fileRewardManager.saveRewards(tempInventory);

                    Player player = (Player) event.getWhoClicked();
                    player.sendMessage("Przedmioty zostały zapisane!");

                    player.closeInventory();
                } else if ("Reset".equals(clickedItemName)) {
                    event.setCancelled(true);
                    String rewardType = fileRewardManager.getRewardType();

                    // Resetuj czas dla odpowiedniego typu nagrody
                    switch (rewardType) {
                        case "daily":
                            mainClass.updateDailyLastScheduledTime();
                            break;
                        case "weekly":
                            mainClass.updateWeeklyLastScheduledTime();
                            break;
                        case "monthly":
                            mainClass.updateMonthlyLastScheduledTime();
                            break;
                    }

                    Player player = (Player) event.getWhoClicked();
                    player.sendMessage(rewardType + " last scheduled time has been reset!");
                }
                else if ("Reedem".equals(clickedItemName)) {
                    event.setCancelled(true);
                    String rewardType = fileRewardManager.getRewardType();
                    mainClass.rewardTopPlayers(rewardType);
                    Player player = (Player) event.getWhoClicked();
                    player.sendMessage("Nagrody zostały przyznane!");
                }

            }
        }
    }

}
