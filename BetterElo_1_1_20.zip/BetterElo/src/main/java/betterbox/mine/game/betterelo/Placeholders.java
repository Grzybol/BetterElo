package betterbox.mine.game.betterelo;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

public class Placeholders extends PlaceholderExpansion {

    private final DataManager dataManager;
    private BetterElo betterElo;

    public Placeholders(DataManager dataManager, BetterElo betterElo) {

        this.dataManager = dataManager;
        this.betterElo = betterElo; // Inicjalizujemy referencję do BetterElo
    }

    @Override
    public @NotNull String getIdentifier() {
        return "be";
    }

    @Override
    public @NotNull String getAuthor() {
        return "grzybol";
    }

    @Override
    public @NotNull String getVersion() {
        return "1.0";
    }

    @Override
    public boolean persist() {
        return true;
    }
    public String formatTime(long milliseconds) {
        if (milliseconds < 0) {
            return "Time is up!";
        }

        long totalSeconds = milliseconds / 1000;
        long days = totalSeconds / (24 * 3600);
        long hours = (totalSeconds % (24 * 3600)) / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;

        StringBuilder timeString = new StringBuilder();

        if (days > 0) {
            timeString.append("days: ").append(days).append(" ");
        }
        if (hours > 0) {
            timeString.append("hours: ").append(hours).append(" ");
        }
        if (minutes > 0) {
            timeString.append("minutes: ").append(minutes).append(" ");
        }
        if (seconds > 0 || timeString.length() == 0) {
            timeString.append("seconds: ").append(seconds);
        }

        return timeString.toString().trim();
    }


    @Override
    public String onPlaceholderRequest(Player player, String identifier) {
        // Sprawdź, który placeholder jest używany
        if (player != null) {
            if (identifier.equals("player")) {
                // Placeholder "{betterelo_player}" - zwraca punkty gracza
                double points = dataManager.getPoints(player.getUniqueId().toString());
                return String.valueOf(points);
            } else if (identifier.equals("rank")) {
                // Placeholder "{betterelo_rank}" - zwraca miejsce w rankingu gracza
                int rank = dataManager.getPlayerRank(player.getUniqueId().toString());
                return String.valueOf(rank);
            } else if (identifier.startsWith("points_top")) {
                // Placeholder "{betterelo_points_top<n>}" - zwraca punkty gracza na pozycji n w rankingu
                int position = Integer.parseInt(identifier.replace("points_top", ""));
                double points = dataManager.getPointsAtPosition(position,dataManager.playerPoints);
                return String.valueOf(points);
            } else if (identifier.startsWith("player_top")) {
                // Placeholder "{betterelo_player_top<n>}" - zwraca nazwę gracza na pozycji n w rankingu
                int position = Integer.parseInt(identifier.replace("player_top", ""));
                String playerName = dataManager.getPlayerAtPosition(position,dataManager.playerPoints);
                return playerName != null ? playerName : "No Player";
            } else if (identifier.startsWith("daily_points_top")) {
                // Placeholder "{betterelo_points_top<n>}" - zwraca punkty gracza na pozycji n w rankingu
                int position = Integer.parseInt(identifier.replace("daily_points_top", ""));
                double points = dataManager.getPointsAtPosition(position,dataManager.dailyPlayerPoints);
                return String.valueOf(points);
            } else if (identifier.startsWith("daily_player_top")) {
                // Placeholder "{betterelo_player_top<n>}" - zwraca nazwę gracza na pozycji n w rankingu
                int position = Integer.parseInt(identifier.replace("daily_player_top", ""));
                String playerName = dataManager.getPlayerAtPosition(position,dataManager.dailyPlayerPoints);
                return playerName != null ? playerName : "No Player";
            }else if (identifier.startsWith("weekly_points_top")) {
                // Placeholder "{betterelo_points_top<n>}" - zwraca punkty gracza na pozycji n w rankingu
                int position = Integer.parseInt(identifier.replace("weekly_points_top", ""));
                double points = dataManager.getPointsAtPosition(position,dataManager.weeklyPlayerPoints);
                return String.valueOf(points);
            } else if (identifier.startsWith("weekly_player_top")) {
                // Placeholder "{betterelo_player_top<n>}" - zwraca nazwę gracza na pozycji n w rankingu
                int position = Integer.parseInt(identifier.replace("weekly_player_top", ""));
                String playerName = dataManager.getPlayerAtPosition(position,dataManager.weeklyPlayerPoints);
                return playerName != null ? playerName : "No Player";
            }else if (identifier.startsWith("monthly_points_top")) {
                // Placeholder "{betterelo_points_top<n>}" - zwraca punkty gracza na pozycji n w rankingu
                int position = Integer.parseInt(identifier.replace("monthly_points_top", ""));
                double points = dataManager.getPointsAtPosition(position,dataManager.monthlyPayerPoints);
                return String.valueOf(points);
            } else if (identifier.startsWith("monthly_player_top")) {
                // Placeholder "{betterelo_player_top<n>}" - zwraca nazwę gracza na pozycji n w rankingu
                int position = Integer.parseInt(identifier.replace("monthly_player_top", ""));
                String playerName = dataManager.getPlayerAtPosition(position,dataManager.monthlyPayerPoints);
                return playerName != null ? playerName : "No Player";
            } else if (identifier.startsWith("daily_tl")){
                return formatTime(betterElo.getRemainingTimeForDailyRewards());
            }else if (identifier.startsWith("weekly_tl")){
                return formatTime(betterElo.getRemainingTimeForWeeklyRewards());
            }else if (identifier.startsWith("monthly_tl")){
                return formatTime(betterElo.getRemainingTimeForMonthlyRewards());
            }
        } else {
            // Gracz jest offline
            OfflinePlayer offlinePlayer = dataManager.getOfflinePlayer(identifier);

            if (offlinePlayer != null) {
                if (identifier.equals("killed")) {
                    // Placeholder "{betterelo_killed}" - zwraca punkty ofiary
                    double victimPoints = dataManager.getPoints(offlinePlayer.getUniqueId().toString());
                    return String.valueOf(victimPoints);
                } else if (identifier.equals("killer")) {
                    // Placeholder "{betterelo_killer}" - zwraca punkty zabójcy
                    double killerPoints = dataManager.getPoints(offlinePlayer.getUniqueId().toString());
                    return String.valueOf(killerPoints);
                }
            }
        }

        return null; // Placeholder nie został rozpoznany
    }
}
