package betterbox.mine.game.betterelo;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.math.RoundingMode;
import org.bukkit.plugin.java.JavaPlugin;


public class Event implements Listener {

    private final DataManager dataManager;
    private final JavaPlugin plugin;
    private final PluginLogger pluginLogger; // Dodajemy referencję do PluginLogger


    public Event(DataManager dataManager, PluginLogger pluginLogger, JavaPlugin plugin ) {
        this.plugin = plugin;
        this.dataManager = dataManager;
        this.pluginLogger = pluginLogger; // Inicjalizujemy PluginLogger

    }
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        String playerName = player.getName();
        pluginLogger.log("Event: onPlayerJoin: gracz "+playerName+" wszedl na serwer");
        String playerUUID = player.getUniqueId().toString();
        if (!dataManager.playerExists(playerUUID)) {
            pluginLogger.log("Event: onPlayerJoin: Gracz nie istnieje w bazie danych. Nadawanie punktów...");
            dataManager.setPoints(playerUUID, 1500); // Nadaj 1500 punktów nowym graczom
        } else {
            pluginLogger.log("Event: onPlayerJoin: Gracz już istnieje w bazie danych.");
        }





    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer != null && !killer.equals(victim)) {
            // Gracz zabił innego gracza
            double victimElo = getElo(victim.getUniqueId().toString());
            double killerElo = getElo(killer.getUniqueId().toString());
            double maxElo = getMaxElo();
            pluginLogger.log("onPlayerDeath: maxElo:"+maxElo+" victimElo:"+victimElo+" killerElo:"+killerElo);
            double basePoints = 10;
            double pointsEarned = calculatePointsEarned(basePoints, killerElo, victimElo, maxElo);
            pluginLogger.log("onPlayerDeath: pointsEarned:"+pointsEarned);


            // Dodaj punkty graczowi, który zabił
            addPoints(killer.getUniqueId().toString(), pointsEarned);

            // Inform the killer about the points earned and victim's points
            DecimalFormat df = new DecimalFormat("#.##");
            killer.sendMessage(ChatColor.GREEN + "You have earned " + df.format(pointsEarned) + " points! " + victim.getName() + " now has " + df.format(victimElo - pointsEarned) + " points.");

            // Odejmij punkty graczowi, który zginął
            subtractPoints(victim.getUniqueId().toString(), pointsEarned);

            // Inform the victim about the points lost and killer's points
            victim.sendMessage(ChatColor.RED + "You have lost " + df.format(pointsEarned) + " points! " + killer.getName() + " now has " + df.format(killerElo + pointsEarned) + " points.");
        }
    }
    private double calculatePointsEarned(double base, double elo1, double elo2, double maxElo) {
        double eloDifference = elo1 - elo2;
        double normalizedDifference = eloDifference / (maxElo + 1);
        double points = base * (1 - normalizedDifference);
        pluginLogger.log("calculatePointsEarned: eloDifference:"+eloDifference+" normalizedDifference:"+normalizedDifference+" points:"+points);
        pluginLogger.log("Event: calculatePointsEarned: PointsEarnedOut: "+(double)Math.round(points*100));
        pluginLogger.log("Event: calculatePointsEarned: PointsEarnedOut/100: "+(double)Math.round(points*100)/100);
        return (double)Math.round(points*100)/100;
    }


    private void addPoints(String playerUUID, double points) {
        // Uzyskaj aktualną ilość punktów gracza i aktualizuj DataManager aby obsługiwał double
        double currentPoints = dataManager.getPoints(playerUUID);
        pluginLogger.log("addPoints: currentPoints:"+currentPoints);
        currentPoints += points;
        pluginLogger.log("addPoints: currentPoints:"+currentPoints);
        dataManager.setPoints(playerUUID, (double)Math.round(currentPoints*100)/100);
    }

    private void subtractPoints(String playerUUID, double points) {
        // Uzyskaj aktualną ilość punktów gracza i aktualizuj DataManager aby obsługiwał double
        double currentPoints = dataManager.getPoints(playerUUID);
        pluginLogger.log("subtractPoints: currentPoints:"+currentPoints);
        if (currentPoints - points < 0) {
            currentPoints = 0;
        } else {
            currentPoints -= points;
        }
        pluginLogger.log("subtractPoints: currentPoints:"+currentPoints);
        dataManager.setPoints(playerUUID, (double)Math.round(currentPoints*100)/100);
    }
    private double getElo(String playerUUID) {
        // Zaktualizuj metodę getPoints w DataManager, aby zwracała double
        return dataManager.getPoints(playerUUID);
    }


    private double getMaxElo() {
        // Pobierz maksymalną wartość ELO z DataManager lub innego źródła
        return dataManager.getMaxElo();
    }


}
