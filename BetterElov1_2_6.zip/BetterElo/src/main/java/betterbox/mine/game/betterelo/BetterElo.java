package betterbox.mine.game.betterelo;

import org.bukkit.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;

public final class BetterElo extends JavaPlugin {

    private PluginLogger pluginLogger;
    private long lastScheduledTimeDaily;
    private long lastScheduledTimeWeekly;
    private long lastScheduledTimeMonthly;

    private DataManager dataManager;
    private Placeholders placeholders;
    private GuiManager guiManager;
    private FileRewardManager fileRewardManager;
    private Event event;

    // Pola z RewardManager
    private BukkitTask dailyTask;
    private BukkitTask weeklyTask;
    private BukkitTask monthlyTask;
    private BetterEloCommand betterEloCommand;
    private final Map<String, Boolean> rewardStates = new HashMap<>();


    @Override
    public void onEnable() {
        // Inicjalizacja PluginLoggera
        pluginLogger = new PluginLogger(getDataFolder().getAbsolutePath());

        pluginLogger.log("Inicjalizacja pluginu BetterElo...");

        pluginLogger = new PluginLogger(getDataFolder().getAbsolutePath());
        pluginLogger.log("Zaladowano loggera.");

        // Przekazujemy pluginLogger do innych klas
        dataManager = new DataManager(this, pluginLogger);
        pluginLogger.log("Zaladowano DataManager.");
        pluginLogger.log("Zaladowano RewardManager.");
        // ... dla innych klas również
        dataManager.initializeDataFolder();
        pluginLogger.log("Zaladowano folder.");
        dataManager.initializeDatabaseFile();
        pluginLogger.log("Zaladowano baze danych.");
        dataManager.loadDataFromFile();
        pluginLogger.log("DataManager został zainicjowany i dane zostały wczytane.");

        // Inicjalizacja RewardManager
        pluginLogger.log("RewardManager został zainicjowany.");

        // Inicjalizacja FileRewardManager
        fileRewardManager = new FileRewardManager(this, pluginLogger);
        // Jeśli FileRewardManager wymaga inicjalizacji, dodaj tutaj

        // Inicjalizacja GuiManager
        guiManager = new GuiManager(fileRewardManager, pluginLogger, this, dataManager);
        getServer().getPluginManager().registerEvents(guiManager, this);

        // Inicjalizacja Placeholders
        placeholders = new Placeholders(dataManager, this);
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            placeholders.register();
            pluginLogger.log("Placeholders zostały zarejestrowane w PlaceholderAPI.");
        } else {
            pluginLogger.log("Warning: PlaceholderAPI nie zostało znalezione. Placeholderów nie będzie dostępnych.");
        }

        // Rejestracja komendy
        getCommand("be").setExecutor(new BetterEloCommand(this, dataManager, guiManager, pluginLogger, this));

        // Rejestracja listenera eventów
        event = new Event(dataManager, pluginLogger,this);
        getServer().getPluginManager().registerEvents(event, this);

        pluginLogger.log("Plugin BetterElo został włączony pomyślnie.");
        // Inicjalizacja RewardManagera (kod z konstruktora RewardManager)
        rewardStates.put("daily", true);
        rewardStates.put("weekly", true);
        rewardStates.put("monthly", true);

        // Inicjalizacja nagród i ich harmonogramów (kod z metody onEnable z klasy RewardManager)
        loadRewards();
        pluginLogger.log("Planowanie nagród dziennych...");
        scheduleDailyRewards();

        pluginLogger.log("Planowanie nagród tygodniowych...");
        scheduleWeeklyRewards();

        pluginLogger.log("Planowanie nagród miesięcznych...");
        scheduleMonthlyRewards();

    }

    @Override
    public void onDisable() {
        pluginLogger.log("Zapisywanie danych przed wyłączeniem pluginu...");
        dataManager.saveDataToFile();
        dataManager.saveDataToFileDaily();
        dataManager.saveDataToFileWeekly();
        dataManager.saveDataToFileMonthly();
        pluginLogger.log("Plugin BetterElo został wyłączony.");
        // Wyłączanie nagród (kod z metody onDisable z klasy RewardManager)
        if (dailyTask != null) dailyTask.cancel();
        if (weeklyTask != null) weeklyTask.cancel();
        if (monthlyTask != null) monthlyTask.cancel();
    }

    // Dodajemy nowe metody do uzyskania pozostałego czasu dla nagród
    public long getRemainingTimeForDailyRewards() {
        lastScheduledTimeDaily = getConfig().getLong("dailyLastScheduledTime", System.currentTimeMillis());
        return TimeUnit.DAYS.toMillis(1) - (System.currentTimeMillis() - lastScheduledTimeDaily);
    }

    public long getRemainingTimeForWeeklyRewards() {
        lastScheduledTimeWeekly = getConfig().getLong("weeklyLastScheduledTime", System.currentTimeMillis());
        return TimeUnit.DAYS.toMillis(7) - (System.currentTimeMillis() - lastScheduledTimeWeekly);
    }

    public long getRemainingTimeForMonthlyRewards() {
        lastScheduledTimeMonthly = getConfig().getLong("monthlyLastScheduledTime", System.currentTimeMillis());

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(lastScheduledTimeMonthly);
        calendar.add(Calendar.MONTH, 1);
        long nextRunTime = calendar.getTimeInMillis();

        return nextRunTime - System.currentTimeMillis();
    }

    private void loadRewards() {
        for (String rewardType : rewardStates.keySet()) {
            File rewardFile = new File(getDataFolder(), rewardType + ".yml");
            if (!rewardFile.exists()) {
                createDefaultRewardFile(rewardFile, rewardType);
            } else {
                loadReward(rewardFile, rewardType);
            }
        }
    }

    private void createDefaultRewardFile(File rewardFile, String rewardType) {
        try {
            rewardFile.createNewFile();
            FileConfiguration rewardConfig = YamlConfiguration.loadConfiguration(rewardFile);

            // Utwórz domyślne nagrody
            rewardConfig.set("material", "DIAMOND");
            rewardConfig.set("amount", 1);
            rewardConfig.save(rewardFile);

            System.out.println("Created default reward file for: " + rewardType);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadReward(File rewardFile, String rewardType) {
        FileConfiguration rewardConfig = YamlConfiguration.loadConfiguration(rewardFile);
        String materialName = rewardConfig.getString("material", "DIAMOND");
        Material material = Material.getMaterial(materialName);
        int amount = rewardConfig.getInt("amount", 1);

        // Zapisz nagrody w mapie lub innym miejscu, aby je później użyć
        // Na przykład: rewardsMap.put(rewardType, new ItemStack(material, amount));
        System.out.println("Loaded reward for " + rewardType + ": " + material + " x" + amount);
    }

    public void updateDailyLastScheduledTime() {
        FileConfiguration config = getConfig();
        config.set("dailyLastScheduledTime", System.currentTimeMillis());
        saveConfig();
    }

    public void updateWeeklyLastScheduledTime() {
        FileConfiguration config = getConfig();
        config.set("weeklyLastScheduledTime", System.currentTimeMillis());
        saveConfig();
    }

    public void updateMonthlyLastScheduledTime() {
        FileConfiguration config = getConfig();
        config.set("monthlyLastScheduledTime", System.currentTimeMillis());
        saveConfig();
    }
    private void scheduleDailyRewards() {

            FileConfiguration config = getConfig();
            lastScheduledTimeDaily = config.getLong("dailyLastScheduledTime", System.currentTimeMillis());

            long delay = (TimeUnit.DAYS.toMillis(1) - (System.currentTimeMillis() - lastScheduledTimeDaily)) / 1000 * 20;
            if (delay < 0) {
                rewardTopPlayers("daily");
                scheduleDailyRewards();
                updateDailyLastScheduledTime();
                return;
            }

            dailyTask = new BukkitRunnable() {
                @Override
                public void run() {
                    if (rewardStates.get("daily")) {
                        rewardTopPlayers("daily");
                        config.set("dailyLastScheduledTime", System.currentTimeMillis() + TimeUnit.DAYS.toMillis(1));
                        saveConfig();
                        scheduleDailyRewards();
                    }
                }
            }.runTaskLater(this, delay);



    }



    private void scheduleWeeklyRewards() {
        FileConfiguration config = getConfig();
        lastScheduledTimeWeekly = config.getLong("weeklyLastScheduledTime", System.currentTimeMillis());

        long delay = (TimeUnit.DAYS.toMillis(7) - (System.currentTimeMillis() - lastScheduledTimeWeekly)) / 1000 * 20;
        if (delay < 0) {
            rewardTopPlayers("weekly");
            scheduleWeeklyRewards();
            updateWeeklyLastScheduledTime();
            return;
        }

        weeklyTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (rewardStates.get("weekly")) {
                    rewardTopPlayers("weekly");
                    config.set("weeklyLastScheduledTime", System.currentTimeMillis() + TimeUnit.DAYS.toMillis(7));
                    saveConfig();
                    scheduleWeeklyRewards();
                }
            }
        }.runTaskLater(this, delay);


    }

    // Wartość 'monthlyLastScheduledTime' przechowuje czas w milisekundach, kiedy zadanie miesięczne zostało ostatnio zaplanowane
    private void scheduleMonthlyRewards() {
        FileConfiguration config = getConfig();
        lastScheduledTimeMonthly = config.getLong("monthlyLastScheduledTime", System.currentTimeMillis());

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(lastScheduledTimeMonthly);
        calendar.add(Calendar.MONTH, 1);
        long nextRunTime = calendar.getTimeInMillis();
        long delay = (nextRunTime - System.currentTimeMillis()) / 1000 * 20;

        if (delay < 0) {
            rewardTopPlayers("monthly");
            scheduleMonthlyRewards();
            updateMonthlyLastScheduledTime();
            return;
        }

        monthlyTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (rewardStates.get("monthly")) {
                    rewardTopPlayers("monthly");
                    config.set("monthlyLastScheduledTime", nextRunTime);
                    saveConfig();
                    scheduleMonthlyRewards();
                }
            }
        }.runTaskLater(this, delay);


    }

    public void rewardTopPlayers(String rewardType) {
        pluginLogger.log(PluginLogger.LogLevel.INFO, "BetterElo: rewardTopPlayers: rewardType: "+rewardType);
        for (int i = 1; i <= 10; i++) {
            String playerName = null;
            if(rewardType.equals("daily")){
                playerName = dataManager.getPlayerAtPosition(i,dataManager.dailyPlayerPoints);

            }else if(rewardType.equals("weekly")){
                playerName = dataManager.getPlayerAtPosition(i,dataManager.weeklyPlayerPoints);

            }else if(rewardType.equals("monthly")){
                playerName = dataManager.getPlayerAtPosition(i,dataManager.monthlyPayerPoints);

            }

            if (playerName != null) {
                OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(playerName);
                if (offlinePlayer != null && offlinePlayer.hasPlayedBefore()) {
                    // Ustaw odpowiedni subType zależnie od pozycji gracza
                    String subType;
                    if (i == 1) subType = "top1";
                    else if (i == 2) subType = "top2";
                    else if (i == 3) subType = "top3";
                    else subType = "top4-10";

                    // Ustaw typ nagrody i pobierz odpowiednie nagrody
                    fileRewardManager.setRewardType(guiManager.periodType, subType);
                    List<ItemStack> rewardItems = fileRewardManager.getReward(fileRewardManager.getRewardType());

                    if (rewardItems == null || rewardItems.isEmpty()) {
                        pluginLogger.log(PluginLogger.LogLevel.WARNING, "BetterElo: rewardTopPlayers: Reward items are null or empty for reward type: " + rewardType + "_" + subType);
                        continue;
                    }

                    Player player = offlinePlayer.getPlayer();
                    if (player != null && player.isOnline()) {
                        for (ItemStack rewardItem : rewardItems) {
                            if (player.getInventory().firstEmpty() != -1) {
                                player.getInventory().addItem(rewardItem);
                                pluginLogger.log(PluginLogger.LogLevel.INFO, "BetterElo: rewardTopPlayers: Nagradzanie gracza: " + player.getName());
                            } else {
                                pluginLogger.log(PluginLogger.LogLevel.INFO, "BetterElo: rewardTopPlayers: No space in inventory for player: " + player.getName());
                                break;
                            }
                        }
                    } else {
                        // Gracz jest offline, zapisz nagrodę do późniejszego przyznania
                        saveOfflineReward(playerName, rewardItems);
                        pluginLogger.log(PluginLogger.LogLevel.INFO, "BetterElo: rewardTopPlayers: Player is not online, saving rewards for: " + offlinePlayer.getName());
                    }
                } else {
                    pluginLogger.log(PluginLogger.LogLevel.INFO, "BetterElo: rewardTopPlayers: Player has not played before: " + offlinePlayer.getName());
                }
            } else {
                pluginLogger.log(PluginLogger.LogLevel.INFO, "BetterElo: rewardTopPlayers: No player at position: " + i);
            }
        }
        if(rewardType.equals("daily")){
            dataManager.dailyPlayerPoints.clear();
            dataManager.saveDataToFileDaily();
            updateDailyLastScheduledTime();
        }else if(rewardType.equals("weekly")){
            dataManager.weeklyPlayerPoints.clear();
            dataManager.saveDataToFileWeekly();
            updateWeeklyLastScheduledTime();
        }else if(rewardType.equals("monthly")){
            dataManager.monthlyPayerPoints.clear();
            dataManager.saveDataToFileMonthly();
            updateMonthlyLastScheduledTime();
        }
    }


    private void saveOfflineReward(String playerName, List<ItemStack> rewardItems) {
        File rewardsFile = new File(this.getDataFolder(), "offlineRewards.yml");
        FileConfiguration rewardsConfig = YamlConfiguration.loadConfiguration(rewardsFile);

        List<ItemStack> existingRewards = (List<ItemStack>) rewardsConfig.getList(playerName);
        if (existingRewards == null) {
            existingRewards = new ArrayList<>();
        }
        existingRewards.addAll(rewardItems);

        rewardsConfig.set(playerName, existingRewards);

        try {
            rewardsConfig.save(rewardsFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
