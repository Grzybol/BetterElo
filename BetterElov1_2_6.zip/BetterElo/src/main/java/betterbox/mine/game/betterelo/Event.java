package betterbox.mine.game.betterelo;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.text.DecimalFormat;

public class EventListener implements Listener {
    private final DataManager dataManager;
    private final JavaPlugin plugin;
    private final PluginLogger pluginLogger;

    public EventListener(DataManager dataManager, PluginLogger pluginLogger, JavaPlugin plugin) {
        this.dataManager = dataManager;
        this.pluginLogger = pluginLogger;
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        String playerName = player.getName();
        String playerUUID = player.getUniqueId().toString();

        pluginLogger.log(String.format("Event: onPlayerJoin: gracz %s wszedl na serwer", playerName));

        if (!dataManager.playerExists(playerUUID)) {
            pluginLogger.log("Event: onPlayerJoin: Gracz nie istnieje w bazie danych. Nadawanie punktów...");
            dataManager.setPoints(playerUUID, 1000, "main");
        } else {
            pluginLogger.log("Event: onPlayerJoin: Gracz już istnieje w bazie danych.");
        }
    }

    private double handleKillEvent(String rankingType, Player victim, Player killer) {
        // [Twoja istniejąca logika metody bez zmian]
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        double pointsEarned = handleKillEvent("main", victim, killer);

        handleKillEvent("daily", victim, killer);
        handleKillEvent("weekly", victim, killer);
        handleKillEvent("monthly", victim, killer);

        notifyPlayersAboutPoints(killer, victim, pointsEarned);
    }

    private void notifyPlayersAboutPoints(Player killer, Player victim, double pointsEarned) {
        DecimalFormat df = new DecimalFormat("#.##");
        killer.sendMessage(ChatColor.GREEN + "You have earned " + df.format(pointsEarned) + " points! ");
        victim.sendMessage(ChatColor.RED + "You have lost " + df.format(pointsEarned) + " points! ");
    }

    private double calculatePointsEarned(double base, double elo1, double elo2, double maxElo, double minElo) {
        // [Twoja istniejąca logika metody bez zmian]
    }

    private void updatePoints(String playerUUID, double points, String rankingType, boolean isAdding) {
        double currentPoints = dataManager.getPoints(playerUUID, rankingType);
        pluginLogger.log(String.format("Event: %sPoints: currentPoints: %sBefore: %s",
                (isAdding ? "add" : "subtract"), rankingType, currentPoints));
        currentPoints = isAdding ? currentPoints + points : currentPoints - points;
        pluginLogger.log(String.format("Event: %sPoints: currentPoints: %sAfter: %s",
                (isAdding ? "add" : "subtract"), rankingType, currentPoints));
        dataManager.setPoints(playerUUID, Math.round(currentPoints * 100) / 100.0, rankingType);
        pluginLogger.log(String.format("Event: %sPoints: currentPoints: %s ranking saved", (isAdding ? "add" : "subtract"), rankingType));
    }

    private void addPoints(String playerUUID, double points, String rankingType) {
        updatePoints(playerUUID, points, rankingType, true);
    }

    private void subtractPoints(String playerUUID, double points, String rankingType) {
        updatePoints(playerUUID, points, rankingType, false);
    }

    private double getElo(String playerUUID, String rankingType) {
        return dataManager.getPoints(playerUUID, rankingType);
    }

    private double getMaxElo(String rankingType) {
        return dataManager.getMaxElo(rankingType);
    }
}
