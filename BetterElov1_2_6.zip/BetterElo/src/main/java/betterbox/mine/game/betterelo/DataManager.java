package betterbox.mine.game.betterelo;

import org.bukkit.entity.Player;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.*;
import java.util.*;

import java.io.*;
import java.util.*;

public class DataManager {

    private final JavaPlugin plugin;
    private final File dataFolder;
    private final File databaseFile;
    private final File dailyDatabaseFile;
    private final File weeklyDatabaseFile;
    private final File monthlyDatabaseFile;

    public final Map<String, Double> playerPoints = new HashMap<>();
    public final Map<String, Double> dailyPlayerPoints = new HashMap<>();
    public final Map<String, Double> weeklyPlayerPoints = new HashMap<>();
    public final Map<String, Double> monthlyPayerPoints = new HashMap<>();
    private final PluginLogger pluginLogger; // Dodajemy referencję do PluginLogger

    public DataManager(JavaPlugin plugin, PluginLogger pluginLogger) {
        this.plugin = plugin;
        this.pluginLogger = pluginLogger; // Inicjalizujemy PluginLogger
        this.dataFolder = plugin.getDataFolder();
        this.databaseFile = new File(dataFolder, "database.txt");
        this.dailyDatabaseFile = new File(dataFolder, "daily_database.txt");
        this.weeklyDatabaseFile = new File(dataFolder, "weekly_database.txt");
        this.monthlyDatabaseFile = new File(dataFolder, "monthly_database.txt");

    }
    public void setPoints(String playerUUID, double points, String ranking_type) {
        if (ranking_type.equals("main")) playerPoints.put(playerUUID, points);
        if (ranking_type.equals("daily")) dailyPlayerPoints.put(playerUUID, points);
        if (ranking_type.equals("weekly")) weeklyPlayerPoints.put(playerUUID, points);
        if (ranking_type.equals("monthly")) monthlyPayerPoints.put(playerUUID, points);
        pluginLogger.log("DataManager: setPoints: zapisywanie do bazy..");
        saveDataToFile(); // Zapisz zmienione dane do pliku
        saveDataToFileDaily(); // Zapisz zmienione dane do pliku
        saveDataToFileWeekly(); // Zapisz zmienione dane do pliku
        saveDataToFileMonthly(); // Zapisz zmienione dane do pliku

    }
    public double getPoints(String playerUUID, String ranking_type) {

        if (ranking_type.equals("main")) {
            if (!playerPoints.containsKey(playerUUID)) {
                pluginLogger.log("DataManager: getPoints: defaultMain 1000");
                return 1000; // Gracz nie jest w rankingu

            }
            pluginLogger.log("DataManager: getPoints: main: "+playerPoints.get(playerUUID));
            return playerPoints.get(playerUUID);
        }else  if (ranking_type.equals("daily")){
            if (!dailyPlayerPoints.containsKey(playerUUID)) {
                pluginLogger.log("DataManager: getPoints: defaultDaily 1000");
                return 1000; // Gracz nie jest w rankingu
            }
            pluginLogger.log("DataManager: getPoints: daily: "+dailyPlayerPoints.get(playerUUID));
            return dailyPlayerPoints.get(playerUUID);
        }else  if (ranking_type.equals("weekly")){
            if (!weeklyPlayerPoints.containsKey(playerUUID)) {
                pluginLogger.log("DataManager: getPoints: defaultWeekly 1000");
                return 1000; // Gracz nie jest w rankingu
            }
            pluginLogger.log("DataManager: getPoints: weekly: "+weeklyPlayerPoints.get(playerUUID));
            return weeklyPlayerPoints.get(playerUUID);
        }else  if (ranking_type.equals("monthly")){
            if (!monthlyPayerPoints.containsKey(playerUUID)) {
                pluginLogger.log("DataManager: getPoints: defaultMonthly 1000");
                return 1000; // Gracz nie jest w rankingu
            }
            pluginLogger.log("DataManager: getPoints: Monthly: "+monthlyPayerPoints.get(playerUUID));
            return monthlyPayerPoints.get(playerUUID);
        }else
        return 0;
    }


    public void initializeDataFolder() {
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
    }

    public void initializeDatabaseFile() {



        if (!databaseFile.exists()) {
            try {
                databaseFile.createNewFile();
                pluginLogger.log("DataManager: initializeDatabaseFile: databaseFile");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (!dailyDatabaseFile.exists()) {
            try {
                dailyDatabaseFile.createNewFile();
                pluginLogger.log("DataManager: initializeDatabaseFile: dailyDatabaseFile");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (!weeklyDatabaseFile.exists()) {
            try {
                weeklyDatabaseFile.createNewFile();
                pluginLogger.log("DataManager: initializeDatabaseFile: weeklyDatabaseFile");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (!monthlyDatabaseFile.exists()) {
            try {
                monthlyDatabaseFile.createNewFile();
                pluginLogger.log("DataManager: initializeDatabaseFile: monthlyDatabaseFile");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public int getPlayerRank(String playerUUID) {
        if (!playerPoints.containsKey(playerUUID)) {
            return -1; // Gracz nie jest w rankingu
        }
        double playerPoints = getPoints(playerUUID,"main");
        Map<String, Double> sortedPlayers = sortPlayersByPoints(this.playerPoints);

        int rank = 1;
        for (Map.Entry<String, Double> entry : sortedPlayers.entrySet()) {
            if (entry.getKey().equals(playerUUID)) {
                return rank;
            }
            rank++;
        }

        return rank; // Gracz nie jest w rankingu
    }
    public void loadDataFromFile() {
        playerPoints.clear();
        dailyPlayerPoints.clear();
        weeklyPlayerPoints.clear();
        monthlyPayerPoints.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(databaseFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    String playerUUID = parts[0];
                    double points = Double.parseDouble(parts[1]);
                    playerPoints.put(playerUUID, points);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(dailyDatabaseFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    String playerUUID = parts[0];
                    double points = Double.parseDouble(parts[1]);
                    dailyPlayerPoints.put(playerUUID, points);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(weeklyDatabaseFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    String playerUUID = parts[0];
                    double points = Double.parseDouble(parts[1]);
                    weeklyPlayerPoints.put(playerUUID, points);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(monthlyDatabaseFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    String playerUUID = parts[0];
                    double points = Double.parseDouble(parts[1]);
                    monthlyPayerPoints.put(playerUUID, points);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Używamy nowego loggera do zapisywania wiadomości debugujących
        pluginLogger.log("DataManager: loadDataFromFile: wczytano z bazy..");
    }
    public void saveDataToFileDaily() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dailyDatabaseFile))) {
            for (Map.Entry<String, Double> entry : dailyPlayerPoints.entrySet()) {
                String playerUUID = entry.getKey();
                double points = entry.getValue();
                writer.write(playerUUID + ":" + points);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Używamy nowego loggera do zapisywania wiadomości debugujących
        pluginLogger.log("DtaManager: saveDataToFileDaily");
    }
    public void saveDataToFileWeekly() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(weeklyDatabaseFile))) {
            for (Map.Entry<String, Double> entry : weeklyPlayerPoints.entrySet()) {
                String playerUUID = entry.getKey();
                double points = entry.getValue();
                writer.write(playerUUID + ":" + points);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Używamy nowego loggera do zapisywania wiadomości debugujących
        pluginLogger.log("DtaManager: saveDataToFileWeekly");
    }
    public void saveDataToFileMonthly() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(monthlyDatabaseFile))) {
            for (Map.Entry<String, Double> entry : monthlyPayerPoints.entrySet()) {
                String playerUUID = entry.getKey();
                double points = entry.getValue();
                writer.write(playerUUID + ":" + points);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Używamy nowego loggera do zapisywania wiadomości debugujących
        pluginLogger.log("DtaManager: saveDataToFileMonthly");
    }
    public void saveDataToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(databaseFile))) {
            for (Map.Entry<String, Double> entry : playerPoints.entrySet()) {
                String playerUUID = entry.getKey();
                double points = entry.getValue();
                writer.write(playerUUID + ":" + points);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Używamy nowego loggera do zapisywania wiadomości debugujących
        pluginLogger.log("Dane zapisane do pliku database.txt.");
    }
    public double getMaxElo(String ranking_type) {
        if (ranking_type.equals("main")){
            if (playerPoints.isEmpty()) {
                pluginLogger.log("DataManager: getMaxElo: defaultMain 1000");
                return 1000; // Zwróć 1500, jeśli mapa punktów jest pusta
            }else {
                pluginLogger.log("DataManager: getMaxElo: Main: "+Collections.max(playerPoints.values()));
                return Collections.max(playerPoints.values());
            }
        }else if (ranking_type.equals("daily")){
            if (dailyPlayerPoints.isEmpty()) {
                pluginLogger.log("DataManager: getMaxElo: defaultDaily 1000");
                return 1000; // Zwróć 1500, jeśli mapa punktów jest pusta
            }else {
                pluginLogger.log("DataManager: getMaxElo: Daily: "+Collections.max(dailyPlayerPoints.values()));
                return Collections.max(dailyPlayerPoints.values());
            }
        }else if (ranking_type.equals("weekly")){
            if (weeklyPlayerPoints.isEmpty()) {
                pluginLogger.log("DataManager: getMaxElo: defaultWeekly 1000");
                return 1000; // Zwróć 1500, jeśli mapa punktów jest pusta
            }else {
                pluginLogger.log("DataManager: getMaxElo: Weekly: "+Collections.max(weeklyPlayerPoints.values()));
                return Collections.max(weeklyPlayerPoints.values());
            }
        }else if (ranking_type.equals("monthly")){
            if (monthlyPayerPoints.isEmpty()) {
                pluginLogger.log("DataManager: getMaxElo: defaultMonthly 1000");
                return 1000; // Zwróć 1500, jeśli mapa punktów jest pusta
            }else {
                pluginLogger.log("DataManager: getMaxElo: Monthly: "+Collections.max(monthlyPayerPoints.values()));
                return Collections.max(monthlyPayerPoints.values());
            }
        }else
        return 1000;
    }
    public double getMinElo(String ranking_type) {
        if (ranking_type.equals("main")){
            if (playerPoints.isEmpty()) {
                pluginLogger.log("DataManager: getMaxElo: defaultMain 1000");
                return 1000; // Zwróć 1500, jeśli mapa punktów jest pusta
            }else {
                pluginLogger.log("DataManager: getMaxElo: Main: "+Collections.max(playerPoints.values()));
                return Collections.min(playerPoints.values());
            }
        }else if (ranking_type.equals("daily")){
            if (dailyPlayerPoints.isEmpty()) {
                pluginLogger.log("DataManager: getMaxElo: defaultDaily 1000");
                return 1000; // Zwróć 1500, jeśli mapa punktów jest pusta
            }else {
                pluginLogger.log("DataManager: getMaxElo: Daily: "+Collections.max(dailyPlayerPoints.values()));
                return Collections.min(dailyPlayerPoints.values());
            }
        }else if (ranking_type.equals("weekly")){
            if (weeklyPlayerPoints.isEmpty()) {
                pluginLogger.log("DataManager: getMaxElo: defaultWeekly 1000");
                return 1000; // Zwróć 1500, jeśli mapa punktów jest pusta
            }else {
                pluginLogger.log("DataManager: getMaxElo: Weekly: "+Collections.max(weeklyPlayerPoints.values()));
                return Collections.min(weeklyPlayerPoints.values());
            }
        }else if (ranking_type.equals("monthly")){
            if (monthlyPayerPoints.isEmpty()) {
                pluginLogger.log("DataManager: getMaxElo: defaultMonthly 1000");
                return 1000; // Zwróć 1500, jeśli mapa punktów jest pusta
            }else {
                pluginLogger.log("DataManager: getMaxElo: Monthly: "+Collections.max(monthlyPayerPoints.values()));
                return Collections.min(monthlyPayerPoints.values());
            }
        }else
            return 1000;
    }



    public double getPointsAtPosition(int position, Map<String, Double> points) {
        Map<String, Double> sortedPlayers = sortPlayersByPoints(points);

        int rank = 1;
        for (Map.Entry<String, Double> entry : sortedPlayers.entrySet()) {
            if (rank == position) {
                return entry.getValue(); // Znaleziono gracza na danej pozycji w rankingu
            }
            rank++;
        }

        return 0; // Brak gracza na danej pozycji w rankingu
    }

    public String getPlayerAtPosition(int position, Map<String, Double> points) {
        Map<String, Double> sortedPlayers = sortPlayersByPoints(points);

        int rank = 1;
        for (Map.Entry<String, Double> entry : sortedPlayers.entrySet()) {
            if (rank == position) {
                // Znaleziono gracza na danej pozycji w rankingu
                return getPlayerName(entry.getKey());
            }
            rank++;
        }

        return null; // Brak gracza na danej pozycji w rankingu
    }
    public String getPlayerName(String playerUUID) {
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(UUID.fromString(playerUUID));
        return offlinePlayer != null ? offlinePlayer.getName() : null;
    }
    public OfflinePlayer getOfflinePlayer(String playerIdentifier) {
        // Sprawdź, czy gracz jest online
        Player onlinePlayer = Bukkit.getPlayer(playerIdentifier);
        if (onlinePlayer != null) {
            return onlinePlayer;
        }

        // Gracz jest offline - próba uzyskania obiektu OfflinePlayer
        UUID playerUUID;
        try {
            playerUUID = UUID.fromString(playerIdentifier);
        } catch (IllegalArgumentException e) {
            return null; // Nieprawidłowy identyfikator gracza
        }

        return Bukkit.getOfflinePlayer(playerUUID);
    }
    public boolean playerExists(String playerUUID) {
        loadDataFromFile(); // Wczytaj dane z pliku przed sprawdzeniem

        return playerPoints.containsKey(playerUUID);
    }
    private Map<String, Double> sortPlayersByPoints(Map<String, Double> points) {
        Map<String, Double> sortedPlayers = new LinkedHashMap<>();

        points.entrySet()
                .stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .forEachOrdered(entry -> sortedPlayers.put(entry.getKey(), entry.getValue()));

        return sortedPlayers;
    }


}
